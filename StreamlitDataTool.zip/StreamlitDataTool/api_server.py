from fastapi import FastAPI, APIRouter, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import time
import uuid
import logging
import os
import asyncio
from typing import Optional
import uvicorn

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Sanchalak API", description="Agricultural Voice Assistant API", version="1.0.0")

# Enable CORS for Streamlit frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Models
class ProcessingStatus:
    PENDING = "PENDING"
    PROCESSING = "PROCESSING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"

class AudioProcessingResponse(BaseModel):
    task_id: str
    status: str
    transcribed_text: Optional[str] = None
    translated_text: Optional[str] = None
    detected_language: Optional[str] = None
    confidence_score: Optional[float] = None
    processing_time: float
    error_details: Optional[str] = None

class TextToSpeechResponse(BaseModel):
    task_id: str
    status: str
    audio_path: Optional[str] = None
    translated_text: Optional[str] = None
    response_text: Optional[str] = None
    processing_time: float
    error_details: Optional[str] = None

class TTSRequest(BaseModel):
    text: str
    target_language: str

# Mock AudioIngestionAgent class (replace with your actual implementation)
class AudioIngestionAgent:
    async def initialize(self):
        """Initialize the audio processing agent"""
        logger.info("AudioIngestionAgent initialized")
    
    async def process_audio(self, audio_file) -> AudioProcessingResponse:
        """Process uploaded audio file and return transcription"""
        try:
            # Simulate audio processing
            await asyncio.sleep(1)  # Simulate processing time
            
            # Mock transcription result - replace with actual transcription logic
            mock_text = "नमस्ते, मैं राजस्थान के जयपुर जिले से हूँ और मैं गेहूँ की खेती करता हूँ। मुझे फसल में कीट की समस्या है।"
            
            return AudioProcessingResponse(
                task_id="",  # Will be set by caller
                status=ProcessingStatus.COMPLETED,
                transcribed_text=mock_text,
                translated_text="Hello, I am from Jaipur district of Rajasthan and I grow wheat. I have pest problem in my crop.",
                detected_language="hi",
                confidence_score=0.95,
                processing_time=0.0  # Will be set by caller
            )
        except Exception as e:
            logger.error(f"Audio processing failed: {e}")
            raise e

# Mock translation and TTS functions (replace with your actual implementations)
async def translate_to_target_language(text: str, target_language: str) -> str:
    """Translate text to target language"""
    # Mock agricultural response in Hindi
    agricultural_responses = {
        "hi": "आपकी गेहूँ की फसल में कीट की समस्या के लिए मैं सुझाव देता हूँ: नीम का तेल स्प्रे करें, जैविक कीटनाशक का उपयोग करें, और फसल की नियमित निगरानी करें। मिट्टी की जांच भी कराएं।",
        "en": "For your wheat crop pest problem, I suggest: Apply neem oil spray, use organic pesticides, and monitor your crop regularly. Also get your soil tested.",
        "gu": "તમારા ઘઉંના પાકમાં જંતુની સમસ્યા માટે હું સૂચન આપું છું: લીમડાના તેલનો છંટકાવ કરો, જૈવિક જંતુનાશકનો ઉપયોગ કરો, અને પાકની નિયમિત દેખરેખ કરો.",
        "pa": "ਤੁਹਾਡੀ ਕਣਕ ਦੀ ਫਸਲ ਵਿੱਚ ਕੀੜੇ ਦੀ ਸਮੱਸਿਆ ਲਈ ਮੈਂ ਸੁਝਾਅ ਦਿੰਦਾ ਹਾਂ: ਨਿੰਮ ਦੇ ਤੇਲ ਦਾ ਛਿੜਕਾਅ ਕਰੋ, ਜੈਵਿਕ ਕੀੜੇਮਾਰ ਦੀ ਵਰਤੋਂ ਕਰੋ, ਅਤੇ ਫਸਲ ਦੀ ਨਿਯਮਤ ਨਿਗਰਾਨੀ ਕਰੋ।"
    }
    
    return agricultural_responses.get(target_language, agricultural_responses["en"])

async def synthesize_speech(text: str, language: str) -> TextToSpeechResponse:
    """Generate speech from text"""
    try:
        # Create output directory if it doesn't exist
        os.makedirs("tts_outputs", exist_ok=True)
        
        # Generate a unique filename
        filename = f"response_{uuid.uuid4().hex[:8]}.mp3"
        file_path = os.path.join("tts_outputs", filename)
        
        # Mock TTS generation - replace with actual TTS implementation
        await asyncio.sleep(0.5)  # Simulate TTS processing
        
        # Create a dummy audio file (you would replace this with actual TTS)
        with open(file_path, "wb") as f:
            f.write(b"")  # Empty file for now
        
        return TextToSpeechResponse(
            task_id="",  # Will be set by caller
            status=ProcessingStatus.COMPLETED,
            audio_path=filename,
            response_text=text,
            processing_time=0.0  # Will be set by caller
        )
    except Exception as e:
        logger.error(f"TTS synthesis failed: {e}")
        raise e

# Transcription Routes
transcribe_router = APIRouter(prefix="/transcribe", tags=["Transcription"])

@transcribe_router.post("/", response_model=AudioProcessingResponse)
async def transcribe_audio(file: UploadFile = File(...)):
    task_id = f"audio_{uuid.uuid4().hex[:8]}"
    try:
        start = time.time()
        agent = AudioIngestionAgent()
        await agent.initialize()

        result = await agent.process_audio(file.file)
        result.task_id = task_id
        result.processing_time = time.time() - start
        result.status = ProcessingStatus.COMPLETED

        return result

    except Exception as e:
        logger.exception("Transcription failed.")
        return AudioProcessingResponse(
            task_id=task_id,
            status=ProcessingStatus.FAILED,
            transcribed_text=None,
            translated_text=None,
            detected_language=None,
            confidence_score=None,
            processing_time=0.0,
            error_details=str(e)
        )

# TTS Routes
tts_router = APIRouter(prefix="/tts", tags=["Text-to-Speech"])

@tts_router.post("/", response_model=TextToSpeechResponse)
async def handle_tts(request: TTSRequest):
    task_id = f"tts_{uuid.uuid4().hex[:8]}"
    try:
        start = time.time()
        
        # Translate the input text to the target language
        translated = await translate_to_target_language(request.text, request.target_language)

        # Synthesize speech for the translated text
        tts_result = await synthesize_speech(translated, request.target_language)

        # Set task details
        tts_result.task_id = task_id
        tts_result.translated_text = translated
        tts_result.processing_time = time.time() - start

        return tts_result

    except Exception as e:
        logger.exception("TTS failed.")
        return TextToSpeechResponse(
            task_id=task_id,
            status=ProcessingStatus.FAILED,
            audio_path=None,
            translated_text=None,
            response_text=None,
            processing_time=0.0,
            error_details=str(e)
        )

# Serve audio files
@tts_router.get("/audio/{filename}")
async def get_audio(filename: str):
    file_path = os.path.join("tts_outputs", filename)
    if os.path.exists(file_path):
        return FileResponse(file_path, media_type="audio/mpeg")
    raise HTTPException(status_code=404, detail="Audio file not found")

# Include routers
app.include_router(transcribe_router)
app.include_router(tts_router)

# Health check endpoint
@app.get("/health")
async def health_check():
    return {"status": "healthy", "service": "Sanchalak API"}

@app.get("/")
async def root():
    return {"message": "Sanchalak Agricultural Voice Assistant API", "version": "1.0.0"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)