# api/transcribe_routes.py

from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse
from transcribe import AudioIngestionAgent
from models import AudioProcessingResponse, ProcessingStatus
import time
import uuid
import logging

router = APIRouter(prefix="/transcribe", tags=["Transcription"])
logger = logging.getLogger(__name__)

@router.post("/", response_model=AudioProcessingResponse)
async def transcribe_audio(file: UploadFile = File(...)):
    task_id = f"audio_{uuid.uuid4().hex[:8]}"
    try:
        start = time.time()
        agent = AudioIngestionAgent()
        await agent.initialize()

        result = await agent.process_audio(file.file)
        result.task_id = task_id
        result.processing_time = time.time() - start
        result.status = ProcessingStatus.COMPLETED

        return result

    except Exception as e:
        logger.exception("Transcription failed.")
        return AudioProcessingResponse(
            task_id=task_id,
            status=ProcessingStatus.FAILED,
            transcribed_text=None,
            translated_text=None,
            detected_language=None,
            confidence_score=None,
            processing_time=0.0,
            error_details=str(e)
        )
