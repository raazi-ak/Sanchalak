import requests
import base64
import io
from pydub import AudioSegment
import streamlit as st

BACKEND_URL = "http://127.0.0.1:8000"

# Call transcription API
def transcribe_audio(audio_bytes_io: io.BytesIO) -> dict:
    files = {"file": ("audio.mp3", audio_bytes_io, "audio/mpeg")}
    try:
        response = requests.post(f"{BACKEND_URL}/transcribe/", files=files)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        st.error(f"Transcription failed: {e}")
        return {"status": "FAILED", "error": str(e)}

# Call TTS API
def tts_response(text: str, target_language: str) -> dict:
    payload = {"text": text, "target_language": target_language}
    try:
        response = requests.post(f"{BACKEND_URL}/tts/", json=payload)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        st.error(f"TTS generation failed: {e}")
        return {"status": "FAILED", "error": str(e)}

# Convert uploaded audio to MP3 in BytesIO
def audio_to_bytesio(uploaded_file) -> io.BytesIO:
    try:
        audio = AudioSegment.from_file(uploaded_file)
        mp3_buffer = io.BytesIO()
        audio.export(mp3_buffer, format="mp3")
        mp3_buffer.seek(0)
        return mp3_buffer
    except Exception as e:
        st.error(f"Failed to process audio: {e}")
        return None

# Create auto-playing audio HTML

def autoplay_audio(path):
    try:
        with open(path, "rb") as audio_file:
            audio_bytes = audio_file.read()
        b64 = base64.b64encode(audio_bytes).decode()
        audio_html = f"""
        <audio autoplay controls style="width: 100%;">
            <source src="data:audio/mp3;base64,{b64}" type="audio/mp3">
            Your browser does not support the audio element.
        </audio>
        """
        return audio_html
    except Exception as e:
        return f"<p>🔇 Audio playback error: {str(e)}</p>"
