# Sanchalak - कृषि संवाद

## Overview

Sanchalak is a multilingual agricultural voice assistant application that enables farmers to interact with an AI system using voice commands in their native Indian languages. The application provides audio-based conversations for agricultural guidance and support.

The system is built using Streamlit for the frontend interface and communicates with a backend API service for audio transcription, text-to-speech conversion, and agricultural AI responses.

## System Architecture

### Frontend Architecture
- **Framework**: Streamlit web application
- **UI Components**: 
  - Voice recording interface
  - Language selection dropdown
  - Audio playback capabilities
  - Chat-like conversation display
- **Styling**: Custom CSS with agriculture-themed green color scheme
- **Audio Handling**: HTML5 audio components with autoplay functionality

### Backend Architecture
- **API Service**: REST API backend (assumed to be running on port 8000)
- **Endpoints**:
  - `/transcribe/` - Audio transcription service
  - `/tts/` - Text-to-speech conversion service
- **Communication**: HTTP requests with JSON/multipart form data

## Key Components

### 1. Frontend Application (`app.py`)
- **Purpose**: Main Streamlit interface for user interactions
- **Features**:
  - Multilingual support (9 Indian languages)
  - Voice recording and playback
  - Real-time audio transcription
  - Agriculture-themed UI design

### 2. Utility Functions (`utils.py`)
- **Audio Processing**: Convert various audio formats to MP3 using pydub
- **API Integration**: Handle communication with backend services
- **Error Handling**: Comprehensive error management for network and processing failures
- **Audio Utilities**: Base64 encoding for audio playback

### 3. Language Support
Supports 10 languages including English and 9 Indian languages:
- English (default), Hindi, Gujarati, Punjabi, Bengali, Telugu, Tamil, Malayalam, Kannada, Odia

## Data Flow

1. **User Input**: User selects language and records audio message
2. **Audio Processing**: Audio is converted to MP3 format using pydub
3. **Transcription**: Audio sent to backend `/transcribe/` endpoint
4. **Response Generation**: Transcribed text processed by agricultural AI (backend)
5. **Text-to-Speech**: AI response converted to audio via `/tts/` endpoint
6. **Audio Playback**: Generated audio played back to user

## External Dependencies

### Python Libraries
- **streamlit**: Web application framework
- **pydub**: Audio processing and format conversion
- **requests**: HTTP client for API communication
- **base64**: Audio encoding for web playback
- **io**: Stream handling for audio data

### External Services
- **Backend API**: Handles transcription, TTS, and AI responses
- **Audio Processing**: Requires ffmpeg for pydub audio conversion

### Configuration
- **BACKEND_URL**: Environment variable for backend service URL (defaults to localhost:8000)

## Deployment Strategy

### Environment Setup
- Requires Python environment with audio processing capabilities
- FFmpeg installation needed for pydub audio conversion
- Backend API service must be accessible

### Configuration Management
- Backend URL configurable via environment variables
- Default development setup assumes local backend on port 8000
- Production deployment would require updated BACKEND_URL

### Scalability Considerations
- Stateless frontend design allows horizontal scaling
- Audio processing handled by backend service
- Session state managed in Streamlit for conversation history

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- July 01, 2025. Initial setup
- July 01, 2025. Added English language support as default option alongside 9 Indian languages. Enhanced multilingual interface with dynamic content switching for all UI elements.
- July 01, 2025. Integrated complete REST API backend system with FastAPI server running on port 8000. Added transcription and TTS endpoints with mock agricultural responses. Restructured layout with side-by-side audio controls and chat conversation positioned at top for easy access.